<?php
require_once "DAO.php";

if (!isset($_SESSION)) session_start();

// Ako je korisnik ulogovan:
if (isset($_SESSION["korisnik"]) && $_SESSION["korisnik"] != "") {

    $dao = new DAO();
    $korisnik = $dao->getById($_SESSION["korisnik"]);
    ?>

    <html>
    <head>
        <meta charset="UTF-8">
        <title>Prikaz korisnika</title>
    </head>

    <body>

    <table style="width:100%; border-collapse: collapse;" border="1">
        <tr>
            <th colspan="2">IP ISPIT — Prikaz korisnika</th>
        </tr>

        <tr>
            <td align="center">PODACI O KORISNIKU</td>
            <td>
                ID: <?= htmlspecialchars($korisnik["id"]) ?><br>
                Username: <?= htmlspecialchars($korisnik["username"]) ?><br>
                Email: <?= htmlspecialchars($korisnik["email"]) ?><br>
                Lozinka: <?= htmlspecialchars($korisnik["lozinka"]) ?><br><br>

                <a href="KorisnikController.php?action=logout">LOGOUT</a>
            </td>
        </tr>

        <tr>
            <th colspan="2">PRIKAZ KORISNIKA — <?= htmlspecialchars($korisnik["username"]) ?></th>
        </tr>
    </table>

    </body>
    </html>

    <?php
} else {
    // Ako korisnik nije ulogovan, vrati ga na početnu stranu
    header("Location: index.php");
}
?>