<?php
require_once 'db.php';

class DAO {
    private $db;

    // SQL upiti
    private $GET_BY_ID = "SELECT * FROM korisnik WHERE id = ?";
    private $UPDATE = "UPDATE korisnik SET username = ?, email = ?, lozinka = ? WHERE id = ?";
    private $INSERT = "INSERT INTO korisnik (username, email, lozinka) VALUES (?, ?, ?)";

    public function __construct() {
        $this->db = DB::createInstance();
    }

    // --- Vraca korisnika po ID-ju ---
    public function getById($id) {
        $statement = $this->db->prepare($this->GET_BY_ID);
        $statement->bindValue(1, $id, PDO::PARAM_INT);
        $statement->execute();

        $result = $statement->fetch(PDO::FETCH_ASSOC);
        return $result ?: null; // vraca null ako ne postoji korisnik
    }

    // --- Menja podatke o korisniku ---
    public function update($korisnik) {
        $statement = $this->db->prepare($this->UPDATE);
        $statement->bindValue(1, $korisnik['username']);
        $statement->bindValue(2, $korisnik['email']);
        $statement->bindValue(3, $korisnik['lozinka']);
        $statement->bindValue(4, $korisnik['id'], PDO::PARAM_INT);
        $statement->execute();
    }

    // --- Ubacuje novog korisnika ---
    public function insert($korisnik) {
        $statement = $this->db->prepare($this->INSERT);
        $statement->bindValue(1, $korisnik['username']);
        $statement->bindValue(2, $korisnik['email']);
        $statement->bindValue(3, $korisnik['lozinka']);
        $statement->execute();

        // vraca ID novog korisnika
        return $this->db->lastInsertId();
    }
}
?>