<?php
require_once "DAO.php";

$msg = isset($msg) ? $msg : "";
$dao = new DAO();

// Ako je forma poslata:
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = isset($_POST["id"]) ? trim($_POST["id"]) : "";
    $username = isset($_POST["username"]) ? trim($_POST["username"]) : "";
    $email = isset($_POST["email"]) ? trim($_POST["email"]) : "";
    $lozinka = isset($_POST["lozinka"]) ? trim($_POST["lozinka"]) : "";

    if (!empty($username) && !empty($email) && !empty($lozinka)) {
        $korisnik = [
            "id" => $id,
            "username" => $username,
            "email" => $email,
            "lozinka" => $lozinka
        ];

        if (!empty($id)) {
            // ako ID postoji — update
            $postoji = $dao->getById($id);
            if ($postoji) {
                $dao->update($korisnik);
                $msg = "Korisnik sa ID $id je uspešno ažuriran.";
            } else {
                $msg = "Korisnik sa ID $id ne postoji.";
            }
        } else {
            // ako ID nije unet — insert
            $noviId = $dao->insert($korisnik);
            $msg = "Novi korisnik je uspešno dodat (ID: $noviId).";
        }
    } else {
        $msg = "Sva polja su obavezna!";
    }
}

// Nakon obrade — uvek prikaži sve korisnike
$korisnici = $dao->getAll(); // ova metoda će biti dodata ispod
?>

<html>
<head>
    <meta charset="UTF-8">
    <title>Korisnici — CRUD</title>
</head>

<body>

<h2>Upravljanje korisnicima</h2>
<p style="color: green;"><?php echo $msg; ?></p>

<!-- Forma -->
<table style="width:100%; border-collapse: collapse;" border="1">
<tr>
    <th colspan="2">Forma za unos / izmenu korisnika</th>
</tr>
<tr>
    <td align="center">
        <form action="index.php" method="post">
            ID (ostavi prazno za novog korisnika):<br>
            <input type="text" name="id"><br><br>

            Username:<br>
            <input type="text" name="username"><br><br>

            Email:<br>
            <input type="email" name="email"><br><br>

            Lozinka:<br>
            <input type="password" name="lozinka"><br><br>

            <input type="submit" value="Sačuvaj">
        </form>
    </td>
</tr>
</table>

<br><br>

<!-- Tabela korisnika -->
<h3>Lista svih korisnika</h3>

<table border="1" style="width:100%; border-collapse: collapse;">
    <tr style="background-color: #efefef;">
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Lozinka</th>
    </tr>

    <?php if (!empty($korisnici)): ?>
        <?php foreach ($korisnici as $k): ?>
            <tr>
                <td><?php echo htmlspecialchars($k['id']); ?></td>
                <td><?php echo htmlspecialchars($k['username']); ?></td>
                <td><?php echo htmlspecialchars($k['email']); ?></td>
                <td><?php echo htmlspecialchars($k['lozinka']); ?></td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr><td colspan="4" align="center">Nema korisnika u bazi.</td></tr>
    <?php endif; ?>
</table>

</body>
</html>
