<?php
require_once "DAO.php";

if (!isset($_SESSION)) session_start();

$dao = new DAO();
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : "";

switch ($_SERVER["REQUEST_METHOD"]) {

    // ------------------- GET -------------------
    case "GET":
        switch ($action) {
            case "edit":
                // Uzimamo ID korisnika iz URL-a, npr. korisnikController.php?action=edit&id=3
                $id = isset($_GET['id']) ? $_GET['id'] : "";

                if (!empty($id)) {
                    $korisnik = $dao->getById($id);

                    if ($korisnik) {
                        include "korisnik_forma.php"; // prikaz forme sa popunjenim podacima
                    } else {
                        $msg = "Korisnik sa ID $id nije pronađen.";
                        include "poruka.php";
                    }
                } else {
                    $msg = "Nije prosleđen ID korisnika.";
                    include "poruka.php";
                }
                break;

            default:
                // Ako nema akcije, samo prikaži praznu formu za unos novog korisnika
                $korisnik = ["id" => "", "username" => "", "email" => "", "lozinka" => ""];
                include "korisnik_forma.php";
                break;
        }
        break;

    // ------------------- POST -------------------
    case "POST":
        $id = isset($_POST["id"]) ? trim($_POST["id"]) : "";
        $username = isset($_POST["username"]) ? trim($_POST["username"]) : "";
        $email = isset($_POST["email"]) ? trim($_POST["email"]) : "";
        $lozinka = isset($_POST["lozinka"]) ? trim($_POST["lozinka"]) : "";

        if (!empty($username) && !empty($email) && !empty($lozinka)) {
            $korisnik = [
                "id" => $id,
                "username" => $username,
                "email" => $email,
                "lozinka" => $lozinka
            ];

            if (!empty($id)) {
                // ažuriranje postojećeg korisnika
                $postojeci = $dao->getById($id);
                if ($postojeci) {
                    $dao->update($korisnik);
                    $msg = "Uspešno ažuriran korisnik ID: $id.";
                } else {
                    $msg = "Korisnik sa ID $id ne postoji!";
                }
            } else {
                // unos novog korisnika
                $noviId = $dao->insert($korisnik);
                $msg = "Uspešno dodat novi korisnik sa ID: $noviId.";
            }
        } else {
            $msg = "Sva polja su obavezna!";
        }

        include "poruka.php";
        break;
}
?>